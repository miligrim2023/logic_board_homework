var input_value = [false, false, false, false];
var input = document.querySelectorAll(".in .elem");
var canvas = document.querySelector(".svg");
var out = document.querySelector(".out");
var or = document.querySelector(".or");
var not = document.querySelector(".not");
var and = document.querySelector(".and");
var my = document.querySelector("#for_test"); 

function start() {
    for (var i = 0; i < 3; i++) {
        input[i].style.backgroundColor = input_value[i] ? "green" : "red";
        my.style.backgroundColor = !input_value[2] ?  "yellow" : "red";
        out.style.backgroundColor = (input_value[0] && !(input_value[2] || input_value[1])) ? "green" : "red";
        and.style.backgroundColor = (input_value[0] && !(input_value[2] || input_value[1])) ? "green" : "red";
        or.style.backgroundColor = (input_value[2] || input_value[1]) ? "green" : "red";
        not.style.backgroundColor = !(input_value[2] || input_value[1]) ? "green" : "red";
        input[i].addEventListener("click", onEnterClick);
    }
}

function onEnterClick(event) {
    var test = (document.querySelector("#for_test") !== null) ? event.currentTarget.className : "elem in4";
    var num = Number(test[7])-1;
    if (num === 3) {
        for_add = document.createElement("div");
        for_add.id = "for_test";
        for_add.style.backgroundColor = !input_value[3] ?  "yellow" : "red";
        for_add.className = "elem need";
        for_add.innerHTML = '<p style="color: black; font-weight: bold;">Сделал Белоусов Матвей!!!</p>';
        document.querySelector(".logic_board").appendChild(for_add);
    } else {
        input_value[num] = !input_value[num];
        input[num].style.backgroundColor = input_value[num] ? "green" : "red";
        out.style.backgroundColor = (input_value[0] && !(input_value[2] || input_value[1])) ? "green" : "red";
        and.style.backgroundColor = (input_value[0] && !(input_value[2] || input_value[1])) ? "green" : "red";
        or.style.backgroundColor = (input_value[2] || input_value[1]) ? "green" : "red";
        not.style.backgroundColor = !(input_value[2] || input_value[1]) ? "green" : "red";
    }
}

start();
